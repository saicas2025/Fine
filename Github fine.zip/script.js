
const proxyURL = "https://preventivo-ai-proxy.onrender.com/api";

function showTab(tab) {
  document.getElementById("preventivo").style.display = (tab === 'preventivo') ? 'block' : 'none';
  document.getElementById("chat").style.display = (tab === 'chat') ? 'block' : 'none';
}

async function sendPDF() {
  const fileInput = document.getElementById("pdfFile");
  if (!fileInput.files.length) {
    alert("Carica un PDF prima!");
    return;
  }
  const formData = new FormData();
  formData.append("file", fileInput.files[0]);

  document.getElementById("result").textContent = "Elaborazione in corso...";

  try {
    const res = await fetch(proxyURL + "/analyze-pdf", {
      method: "POST",
      body: formData
    });
    const data = await res.json();
    document.getElementById("result").textContent = data.result || "Nessun risultato";
  } catch (err) {
    document.getElementById("result").textContent = "Errore: " + err;
  }
}

async function sendMessage() {
  const input = document.getElementById("userInput");
  const chatBox = document.getElementById("chatBox");
  const message = input.value.trim();
  if (!message) return;

  chatBox.innerHTML += `<div class='user'>Tu: ${message}</div>`;
  input.value = "";

  try {
    const res = await fetch(proxyURL + "/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message })
    });
    const data = await res.json();
    chatBox.innerHTML += `<div class='ai'>AI: ${data.reply}</div>`;
    chatBox.scrollTop = chatBox.scrollHeight;
  } catch (err) {
    chatBox.innerHTML += `<div class='ai'>Errore: ${err}</div>`;
  }
}
